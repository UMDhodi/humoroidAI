from setuptools import setup

setup(name = "Speech_Jarvis",
author = "kaushik shresth",
version = "1.0",
packages = ['Speech'],
install_requires = ['pyttsx3','SpeechRecognition'])
